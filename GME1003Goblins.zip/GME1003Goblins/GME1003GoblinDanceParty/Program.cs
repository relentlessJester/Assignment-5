﻿
using var game = new GME1003GoblinDanceParty.Game1();
game.Run();
